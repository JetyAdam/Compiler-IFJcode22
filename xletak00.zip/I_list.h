//
// Created by Lukáš on 16.10.2022.
//

#include "global_def.h"

#ifndef README_MD_I_LIST_H
#define README_MD_I_LIST_H

void Ilist_insert(Arg_list_type *Root, Arg_list_type *new_node);

#endif //README_MD_I_LIST_H
