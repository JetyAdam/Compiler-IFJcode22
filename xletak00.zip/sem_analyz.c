//
// Created by Lukáš on 30.09.2022.
//

#include "sem_analyz.h"
#include "global_def.h"
#include "SmallMC.h"