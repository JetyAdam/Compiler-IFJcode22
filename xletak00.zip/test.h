//
// Created by Lukáš on 04.09.2022.
//

#ifndef SMALLGC_TEST_H
#define SMALLGC_TEST_H
void testm(int i);
#endif //SMALLGC_TEST_H
